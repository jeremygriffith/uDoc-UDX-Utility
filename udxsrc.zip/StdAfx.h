// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently

#if !defined(AFX_STDAFX_H__9A1D7CFE_F3D1_4081_AE3D_A5F314370426__INCLUDED_)
#define AFX_STDAFX_H__9A1D7CFE_F3D1_4081_AE3D_A5F314370426__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include "mxlparser.h"


#endif // !defined(AFX_STDAFX_H__9A1D7CFE_F3D1_4081_AE3D_A5F314370426__INCLUDED_)
