var relItems = [
["elements",[4]],
["lists",[3]],
["shorthand",[2,3,5,6,7,8]],
["tables",[3]],
["udx",[2,6,7,8]]]
