var relItems = [
["lists",[3]],
["shorthand",[2,3,4,5,6,7]],
["tables",[3]],
["udx",[2,5,6,7]]]
