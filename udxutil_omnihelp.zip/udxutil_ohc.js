var tocItems = [
[1,"The UDX Utility","udx_utility.htm#Xxx1005"],
[2,"Table of Contents","udx_utilityTOC.htm#Xxx1030"],
[2,"The udx Utility","ud_xform.htm#Xxx1034"],
[2,"uDoc Tag Minimization","ud_minimize.htm#Xxx1091"],
[2,"Events and Ranges","ud_events.htm#Xxx1183"],
[2,"Creating New Shorthand Symbols","ud_newshort.htm#Xxx1221"],
[2,"The udx Switches","ud_udxswitch.htm#Xxx1290"],
[2,"The udx.ini File","ud_udxini.htm#Xxx1348"],
[2,"The &lt;udx&gt; Tag","ud_udxtag.htm#Xxx1391"]]
