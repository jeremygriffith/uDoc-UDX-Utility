var tocItems = [
[1,"The UDX Utility","udx_utility.htm#Xxx1005"],
[2,"Table of Contents","udx_utilityTOC.htm#Xxx1028"],
[2,"The udx Utility","ud_xform.htm#Xxx1032"],
[3,"uDoc Tag Minimization","ud_minimize.htm#Xxx1089"],
[3,"Creating New Shorthand Symbols","ud_newshort.htm#Xxx1176"],
[3,"The udx Switches","ud_udxswitch.htm#Xxx1245"],
[3,"The udx.ini File","ud_udxini.htm#Xxx1303"],
[3,"The &lt;udx&gt; Tag","ud_udxtag.htm#Xxx1346"]]
